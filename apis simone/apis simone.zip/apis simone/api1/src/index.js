const express = require("express");
const mongoose = require("mongoose");
mongoose
  .connect(
    "mongodb+srv://user:user@cluster0.7wv9p.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
  )
  .then(() => {
    console.log("Conectado");
  })
  .catch((err) => {
    console.log(err);
  });

const app = express();
app.use(express.json());
const port = 3001;

const usuarioSchema = new mongoose.Schema({
  username: String,
  password: String,
});

const userModel = mongoose.model("user", usuarioSchema);

app.post("/addUser", async (req, res) => {
  const user = {
    username: req.body.username,
    password: req.body.password
  };

  if (!username || !password){
    res.status(404).send("Faltam credênciais.")
    return;
    
  }

  try {
    const userToCreate = new userModel({
      username: user.username,
      password: user.password,
    });
    await userToCreate.save();
    res.send(userToCreate);
  } catch (err) {
    res.send("Error Post ", err);
  }



});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
