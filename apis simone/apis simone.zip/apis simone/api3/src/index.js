const express = require('express');
const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://user:user@cluster0.7wv9p.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
.then(()=>{
    console.log('Conectado');
}
).catch((err)=>{
    console.log(err);
});


const app = express();
app.use(express.json());
const port = 3003;

const usuarioSchema = new mongoose.Schema({
    username: String,
    password: String,
});

const userModel = mongoose.model('user', usuarioSchema); 

app.put('/putUser/:id', async (req, res) => {
    const user = {
        id: req.params,
        username: req.body.username,
        password: req.body.password
    }

  console.log(user)
    try{
        await userModel.findByIdAndUpdate(user.id, user);
        res.send("Usuario atualizado");
    }catch(err){
        console.log(err);
        res.send('Error');
    }
});


app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});
