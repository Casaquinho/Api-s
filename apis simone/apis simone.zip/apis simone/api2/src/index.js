const express = require("express");
const mongoose = require("mongoose");
mongoose
  .connect(
    "mongodb+srv://user:user@cluster0.7wv9p.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
  )
  .then(() => {
    console.log("Conectado");
  })
  .catch((err) => {
    console.log(err);
  });

const app = express();
app.use(express.json());
const port = 3002;

const usuarioSchema = new mongoose.Schema({
  username: String,
  password: String,
});

const userModel = mongoose.model("user", usuarioSchema);

app.get("/getUser", async (req, res) => {
  try {
    const users = await userModel.find();
    res.json(users);
  } catch {
    res.status(500).send();
  }
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
