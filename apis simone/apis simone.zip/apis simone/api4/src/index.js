const express = require('express');
const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://user:user@cluster0.7wv9p.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
.then(()=>{
    console.log('Conectado');
}
).catch((err)=>{
    console.log(err);
});


const app = express();
app.use(express.json());
const port = 3004;

const usuarioSchema = new mongoose.Schema({
    username: String,
    password: String,
});

const userModel = mongoose.model('user', usuarioSchema); 

app.delete('/DeletUser', async (req, res) => {
    const user = {
       id: req.body.id
    }

    try{
        await userModel.findByIdAndDelete(user.id);
        res.send("usuario deletado");
    }catch(err){
        console.log(err);
        res.send('Error');
    }
    
});

app.delete('/deleteAll', async (req, res) => {
    try{
        await userModel.deleteMany();
        res.send('Usuarios deletados');
    }catch(err){
        console.log(err);
        res.send('Error');
    }
})

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});
